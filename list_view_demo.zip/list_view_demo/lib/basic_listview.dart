import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class BasicListView extends StatefulWidget {
  const BasicListView({Key? key}) : super(key: key);

  @override
  State<BasicListView> createState() => _BasicListViewState();
}

class _BasicListViewState extends State<BasicListView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Basic List'),
      ),
      body: ListView(
        children: const [
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 1'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Title 2'),
            subtitle: Text('Subtitle 2'),
          ),
        ],
      ),
    );
  }
}
