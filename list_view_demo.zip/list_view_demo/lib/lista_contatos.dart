import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class ListaContatos extends StatefulWidget {
  const ListaContatos({Key? key}) : super(key: key);

  @override
  State<ListaContatos> createState() => _ListaContatosState();
}

class _ListaContatosState extends State<ListaContatos> {
  final List<Contatos> contatos = [
    Contatos('Wendel Eduardo', 'wendeleduardo2002@gmail.com'),
    Contatos('Leticia', 'leticia@gmail.com'),
    Contatos('Dobi', 'dobi@gmail.com'),
    Contatos('Bidu', 'bidu@gmail.com'),
  ];

  /*@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Contatos')),
      body: Container(
        height: 150,
        child: ListView.separated(
          itemCount: contatos.length,
          scrollDirection: Axis.horizontal,
          separatorBuilder: (BuildContext context, int index) =>
              const VerticalDivider(width: 50),
          itemBuilder: (BuildContext context, int index) {
            return Container(
              width: 150,
              color: Colors.red,
            );
          },
        ),
      ),
    );
  }
}*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Contatos')),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            leading: Icon(Icons.home),
            title: Text(contatos[index].nomeCompleto,
                style: TextStyle(fontSize: 20)),
            subtitle:
                Text(contatos[index].email, style: TextStyle(fontSize: 20)),
          );
        },
      ),
    );
  }
}

class Contatos {
  String nomeCompleto;
  String email;

  Contatos(this.nomeCompleto, this.email);
}
