package com.example.list_view_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
